package com.r.events.model

import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.select.Elements
import java.io.IOException
import java.lang.Exception
import kotlin.concurrent.thread
private
class PagesParse(model: Model) {

    var model : Model? = null

    init {
        this.model =model;
    }

    fun convertMonth()
    fun it_events()
    {
        thread {
            val doc: Document
            //создаем объект мероприятия
            val eventObject = EventObject()
            //заполняем его
            try {
                doc = Jsoup.connect("https://it-events.com/").get()


                val div: Elements = doc.getElementsByClass("col-10")
                for(i : Element in div)
                {

                    try {
                        eventObject.setType(i.getElementsByClass("event-list-item__type").text())
                    }catch (e : Exception){}

                    try {
                        eventObject.setName(i.getElementsByClass("event-list-item__title").text())
                    }catch (e : Exception){}

                    try {
                        eventObject.setDate(i.getElementsByClass("event-list-item__info")[0].text())


                    }catch (e : Exception){}

                }


                //отправляем уведомление
                model!!.pushNotification(eventObject.getName(), eventObject.getDate(), null)

            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

}